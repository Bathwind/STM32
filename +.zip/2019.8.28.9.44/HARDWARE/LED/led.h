#ifndef __LED_H
#define __LED_H	 
#include "sys.h" 
#define LED0 PDout(2)
#define LED1 PAout(9)
#define LED2 PAout(10)
#define LED3 PAout(6)
#define LED4 PAout(7)
void Fan_Init(void);//��ʼ��	 				    
#endif
