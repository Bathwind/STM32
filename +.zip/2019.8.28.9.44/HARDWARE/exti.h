#ifndef __exti_H
#define __exti_H
#include "sys.h"
void exti_init(void);

#endif
